export const Logo = () => import('../../components/Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const VuetifyLogo = () => import('../../components/VuetifyLogo.vue' /* webpackChunkName: "components/vuetify-logo" */).then(c => wrapFunctional(c.default || c))
export const CommonFavButton = () => import('../../components/common/FavButton.vue' /* webpackChunkName: "components/common-fav-button" */).then(c => wrapFunctional(c.default || c))
export const CommonImageUpload = () => import('../../components/common/ImageUpload.vue' /* webpackChunkName: "components/common-image-upload" */).then(c => wrapFunctional(c.default || c))
export const OrderCardDetailCard = () => import('../../components/OrderCard/DetailCard.vue' /* webpackChunkName: "components/order-card-detail-card" */).then(c => wrapFunctional(c.default || c))
export const OrderCardListCard = () => import('../../components/OrderCard/ListCard.vue' /* webpackChunkName: "components/order-card-list-card" */).then(c => wrapFunctional(c.default || c))
export const OrderCardStatusCard = () => import('../../components/OrderCard/StatusCard.vue' /* webpackChunkName: "components/order-card-status-card" */).then(c => wrapFunctional(c.default || c))
export const InputFormAddressForm = () => import('../../components/inputForm/AddressForm.vue' /* webpackChunkName: "components/input-form-address-form" */).then(c => wrapFunctional(c.default || c))
export const InputFormPaymentForm = () => import('../../components/inputForm/PaymentForm.vue' /* webpackChunkName: "components/input-form-payment-form" */).then(c => wrapFunctional(c.default || c))
export const InputFormProductForm = () => import('../../components/inputForm/ProductForm.vue' /* webpackChunkName: "components/input-form-product-form" */).then(c => wrapFunctional(c.default || c))
export const InputFormPromotionForm = () => import('../../components/inputForm/PromotionForm.vue' /* webpackChunkName: "components/input-form-promotion-form" */).then(c => wrapFunctional(c.default || c))
export const InputFormReviewForm = () => import('../../components/inputForm/ReviewForm.vue' /* webpackChunkName: "components/input-form-review-form" */).then(c => wrapFunctional(c.default || c))
export const ProductCardItemCard = () => import('../../components/productCard/ItemCard.vue' /* webpackChunkName: "components/product-card-item-card" */).then(c => wrapFunctional(c.default || c))
export const ProductCardSmallCard = () => import('../../components/productCard/SmallCard.vue' /* webpackChunkName: "components/product-card-small-card" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}

# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Logo>` | `<logo>` (components/Logo.vue)
- `<VuetifyLogo>` | `<vuetify-logo>` (components/VuetifyLogo.vue)
- `<CommonFavButton>` | `<common-fav-button>` (components/common/FavButton.vue)
- `<CommonImageUpload>` | `<common-image-upload>` (components/common/ImageUpload.vue)
- `<OrderCardDetailCard>` | `<order-card-detail-card>` (components/OrderCard/DetailCard.vue)
- `<OrderCardListCard>` | `<order-card-list-card>` (components/OrderCard/ListCard.vue)
- `<OrderCardStatusCard>` | `<order-card-status-card>` (components/OrderCard/StatusCard.vue)
- `<InputFormAddressForm>` | `<input-form-address-form>` (components/inputForm/AddressForm.vue)
- `<InputFormPaymentForm>` | `<input-form-payment-form>` (components/inputForm/PaymentForm.vue)
- `<InputFormProductForm>` | `<input-form-product-form>` (components/inputForm/ProductForm.vue)
- `<InputFormPromotionForm>` | `<input-form-promotion-form>` (components/inputForm/PromotionForm.vue)
- `<InputFormReviewForm>` | `<input-form-review-form>` (components/inputForm/ReviewForm.vue)
- `<ProductCardItemCard>` | `<product-card-item-card>` (components/productCard/ItemCard.vue)
- `<ProductCardSmallCard>` | `<product-card-small-card>` (components/productCard/SmallCard.vue)

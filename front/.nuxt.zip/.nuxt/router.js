import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _189736bf = () => interopDefault(import('../pages/addresses/index.vue' /* webpackChunkName: "pages/addresses/index" */))
const _634baf32 = () => interopDefault(import('../pages/admin_error.vue' /* webpackChunkName: "pages/admin_error" */))
const _20692476 = () => interopDefault(import('../pages/cart.vue' /* webpackChunkName: "pages/cart" */))
const _321236c8 = () => interopDefault(import('../pages/checkout.vue' /* webpackChunkName: "pages/checkout" */))
const _7e7e1943 = () => interopDefault(import('../pages/favourites/index.vue' /* webpackChunkName: "pages/favourites/index" */))
const _030aa6b5 = () => interopDefault(import('../pages/home.vue' /* webpackChunkName: "pages/home" */))
const _a2b77e18 = () => interopDefault(import('../pages/inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _7c2f1683 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _b336cf04 = () => interopDefault(import('../pages/orders/index.vue' /* webpackChunkName: "pages/orders/index" */))
const _74795974 = () => interopDefault(import('../pages/payments/index.vue' /* webpackChunkName: "pages/payments/index" */))
const _4a25d37e = () => interopDefault(import('../pages/search.vue' /* webpackChunkName: "pages/search" */))
const _bd309c66 = () => interopDefault(import('../pages/addresses/new.vue' /* webpackChunkName: "pages/addresses/new" */))
const _108b78be = () => interopDefault(import('../pages/admin/orders/index.vue' /* webpackChunkName: "pages/admin/orders/index" */))
const _fa666606 = () => interopDefault(import('../pages/admin/products/index.vue' /* webpackChunkName: "pages/admin/products/index" */))
const _5833a6cb = () => interopDefault(import('../pages/error/404.vue' /* webpackChunkName: "pages/error/404" */))
const _e63cf7f0 = () => interopDefault(import('../pages/error/500.vue' /* webpackChunkName: "pages/error/500" */))
const _125e999e = () => interopDefault(import('../pages/footer/about_us.vue' /* webpackChunkName: "pages/footer/about_us" */))
const _5789982b = () => interopDefault(import('../pages/footer/contact_us.vue' /* webpackChunkName: "pages/footer/contact_us" */))
const _24d54501 = () => interopDefault(import('../pages/footer/customer_services.vue' /* webpackChunkName: "pages/footer/customer_services" */))
const _6fe791d7 = () => interopDefault(import('../pages/footer/privacy_policy.vue' /* webpackChunkName: "pages/footer/privacy_policy" */))
const _73925db4 = () => interopDefault(import('../pages/footer/term_of_use.vue' /* webpackChunkName: "pages/footer/term_of_use" */))
const _38a7bbfb = () => interopDefault(import('../pages/orders/order_confirm.vue' /* webpackChunkName: "pages/orders/order_confirm" */))
const _622f4414 = () => interopDefault(import('../pages/payments/new.vue' /* webpackChunkName: "pages/payments/new" */))
const _77c12c44 = () => interopDefault(import('../pages/users/activate_account.vue' /* webpackChunkName: "pages/users/activate_account" */))
const _61082c6c = () => interopDefault(import('../pages/users/change_email.vue' /* webpackChunkName: "pages/users/change_email" */))
const _53f31e5d = () => interopDefault(import('../pages/users/change_password.vue' /* webpackChunkName: "pages/users/change_password" */))
const _8cdf6852 = () => interopDefault(import('../pages/users/change_profile.vue' /* webpackChunkName: "pages/users/change_profile" */))
const _54fbc980 = () => interopDefault(import('../pages/users/forget_password.vue' /* webpackChunkName: "pages/users/forget_password" */))
const _f838619a = () => interopDefault(import('../pages/users/new.vue' /* webpackChunkName: "pages/users/new" */))
const _1d23eec8 = () => interopDefault(import('../pages/users/reset_password.vue' /* webpackChunkName: "pages/users/reset_password" */))
const _b82c80ea = () => interopDefault(import('../pages/admin/products/new.vue' /* webpackChunkName: "pages/admin/products/new" */))
const _4d7c92a6 = () => interopDefault(import('../pages/admin/orders/_id.vue' /* webpackChunkName: "pages/admin/orders/_id" */))
const _df982ab6 = () => interopDefault(import('../pages/admin/products/_id.vue' /* webpackChunkName: "pages/admin/products/_id" */))
const _e49c4632 = () => interopDefault(import('../pages/addresses/_id.vue' /* webpackChunkName: "pages/addresses/_id" */))
const _9acabb34 = () => interopDefault(import('../pages/orders/_id.vue' /* webpackChunkName: "pages/orders/_id" */))
const _4e796f2e = () => interopDefault(import('../pages/payments/_id.vue' /* webpackChunkName: "pages/payments/_id" */))
const _260d0a65 = () => interopDefault(import('../pages/products/_id.vue' /* webpackChunkName: "pages/products/_id" */))
const _702dfa4d = () => interopDefault(import('../pages/users/_id.vue' /* webpackChunkName: "pages/users/_id" */))
const _9af11928 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/addresses",
    component: _189736bf,
    name: "addresses"
  }, {
    path: "/admin_error",
    component: _634baf32,
    name: "admin_error"
  }, {
    path: "/cart",
    component: _20692476,
    name: "cart"
  }, {
    path: "/checkout",
    component: _321236c8,
    name: "checkout"
  }, {
    path: "/favourites",
    component: _7e7e1943,
    name: "favourites"
  }, {
    path: "/home",
    component: _030aa6b5,
    name: "home"
  }, {
    path: "/inspire",
    component: _a2b77e18,
    name: "inspire"
  }, {
    path: "/login",
    component: _7c2f1683,
    name: "login"
  }, {
    path: "/orders",
    component: _b336cf04,
    name: "orders"
  }, {
    path: "/payments",
    component: _74795974,
    name: "payments"
  }, {
    path: "/search",
    component: _4a25d37e,
    name: "search"
  }, {
    path: "/addresses/new",
    component: _bd309c66,
    name: "addresses-new"
  }, {
    path: "/admin/orders",
    component: _108b78be,
    name: "admin-orders"
  }, {
    path: "/admin/products",
    component: _fa666606,
    name: "admin-products"
  }, {
    path: "/error/404",
    component: _5833a6cb,
    name: "error-404"
  }, {
    path: "/error/500",
    component: _e63cf7f0,
    name: "error-500"
  }, {
    path: "/footer/about_us",
    component: _125e999e,
    name: "footer-about_us"
  }, {
    path: "/footer/contact_us",
    component: _5789982b,
    name: "footer-contact_us"
  }, {
    path: "/footer/customer_services",
    component: _24d54501,
    name: "footer-customer_services"
  }, {
    path: "/footer/privacy_policy",
    component: _6fe791d7,
    name: "footer-privacy_policy"
  }, {
    path: "/footer/term_of_use",
    component: _73925db4,
    name: "footer-term_of_use"
  }, {
    path: "/orders/order_confirm",
    component: _38a7bbfb,
    name: "orders-order_confirm"
  }, {
    path: "/payments/new",
    component: _622f4414,
    name: "payments-new"
  }, {
    path: "/users/activate_account",
    component: _77c12c44,
    name: "users-activate_account"
  }, {
    path: "/users/change_email",
    component: _61082c6c,
    name: "users-change_email"
  }, {
    path: "/users/change_password",
    component: _53f31e5d,
    name: "users-change_password"
  }, {
    path: "/users/change_profile",
    component: _8cdf6852,
    name: "users-change_profile"
  }, {
    path: "/users/forget_password",
    component: _54fbc980,
    name: "users-forget_password"
  }, {
    path: "/users/new",
    component: _f838619a,
    name: "users-new"
  }, {
    path: "/users/reset_password",
    component: _1d23eec8,
    name: "users-reset_password"
  }, {
    path: "/admin/products/new",
    component: _b82c80ea,
    name: "admin-products-new"
  }, {
    path: "/admin/orders/:id",
    component: _4d7c92a6,
    name: "admin-orders-id"
  }, {
    path: "/admin/products/:id",
    component: _df982ab6,
    name: "admin-products-id"
  }, {
    path: "/addresses/:id",
    component: _e49c4632,
    name: "addresses-id"
  }, {
    path: "/orders/:id",
    component: _9acabb34,
    name: "orders-id"
  }, {
    path: "/payments/:id",
    component: _4e796f2e,
    name: "payments-id"
  }, {
    path: "/products/:id?",
    component: _260d0a65,
    name: "products-id"
  }, {
    path: "/users/:id?",
    component: _702dfa4d,
    name: "users-id"
  }, {
    path: "/",
    component: _9af11928,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
